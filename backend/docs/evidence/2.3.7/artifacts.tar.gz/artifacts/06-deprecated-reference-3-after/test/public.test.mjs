import test from 'node:test';
import {deepStrictEqual as same,ok,throws} from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
const root=process.cwd();
const text=(p)=>readFileSync(resolve(root,p),'utf8');
const json=(p)=>JSON.parse(text(p));
const load=(name)=>import(pathToFileURL(resolve(root,'lib',name+'.mjs')).href);
test('task contract',async()=>{
  const {offset}=await load('page');
  throws(()=>offset(),TypeError);
  same(offset('start'),0);
});
